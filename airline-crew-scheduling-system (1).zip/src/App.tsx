import React, { useState, useEffect } from "react";
import {
  Plane,
  Users,
  Calendar,
  FileText,
  Sparkles,
  LogOut,
  Bell,
  Menu,
  X,
  User as UserIcon,
  CheckCircle,
  Clock,
  AlertTriangle
} from "lucide-react";
import { Crew, Flight, LeaveRequest, Notification, User as UserType } from "./types";
import Login from "./components/Login";
import RosterDashboard from "./components/RosterDashboard";
import CrewManagement from "./components/CrewManagement";
import FlightScheduling from "./components/FlightScheduling";
import LeaveRequests from "./components/LeaveRequests";
import AICopilot from "./components/AICopilot";

export default function App() {
  const [session, setSession] = useState<UserType | null>(null);
  const [activeTab, setActiveTab] = useState<string>("Dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  // Core database state synchronized with server
  const [crewList, setCrewList] = useState<Crew[]>([]);
  const [flights, setFlights] = useState<Flight[]>([]);
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [selectedFlightId, setSelectedFlightId] = useState<string | undefined>(undefined);

  // App metrics loading status
  const [dataError, setDataError] = useState<string | null>(null);

  // Fetch initial state matrices
  const loadDatabaseMatrices = async () => {
    try {
      const [crewRes, flightRes, leaveRes, notifRes] = await Promise.all([
        fetch("/api/crew"),
        fetch("/api/flights"),
        fetch("/api/leaves"),
        fetch("/api/notifications"),
      ]);

      if (!crewRes.ok || !flightRes.ok || !leaveRes.ok || !notifRes.ok) {
        throw new Error("Failure reloading airline scheduler rosters.");
      }

      const [crewData, flightData, leaveData, notifData] = await Promise.all([
        crewRes.json(),
        flightRes.json(),
        leaveRes.json(),
        notifRes.json(),
      ]);

      setCrewList(crewData);
      setFlights(flightData);
      setLeaves(leaveData);
      setNotifications(notifData);
    } catch (err: any) {
      setDataError(err.message || "Sever state sync offline.");
    }
  };

  // Autoload on successful session trigger
  useEffect(() => {
    if (session) {
      loadDatabaseMatrices();
    }
  }, [session]);

  const handleLoginSuccess = (user: UserType) => {
    setSession(user);
    setActiveTab("Dashboard");
  };

  const handleLogout = () => {
    setSession(null);
    setMobileMenuOpen(false);
  };

  // CRUD API bridges
  const handleAddNewCrew = async (crewData: Partial<Crew>) => {
    const res = await fetch("/api/crew", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(crewData),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Failed registering new employee record.");
    }

    await loadDatabaseMatrices();
  };

  const handleDeleteCrew = async (id: string) => {
    const res = await fetch(`/api/crew/${id}`, {
      method: "DELETE",
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Removal execution error.");
    }

    await loadDatabaseMatrices();
  };

  const handleAddNewFlight = async (flightData: Partial<Flight>) => {
    const res = await fetch("/api/flights", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(flightData),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Flight dispatch error.");
    }

    await loadDatabaseMatrices();
  };

  const handleAssignCrew = async (flightId: string, crewId: string, override = false) => {
    const res = await fetch(`/api/flights/${flightId}/assign`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ crewId, override }),
    });

    if (!res.ok) {
      const err = await res.json();
      // Catch safety conflicts & forward to component warning overlays
      if (res.status === 409) {
        throw { conflict: true, type: err.type, message: err.message };
      }
      throw new Error(err.message || "Allocation database failure.");
    }

    await loadDatabaseMatrices();
  };

  const handleUpdateCrew = async (crewId: string, updates: Partial<Crew>) => {
    const res = await fetch(`/api/crew/${crewId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Failed to update crew.");
    }
    await loadDatabaseMatrices();
  };

  const handleAddNewLeave = async (leaveData: Partial<LeaveRequest>) => {
    const res = await fetch("/api/leaves", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(leaveData),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Time-off petition filing failure.");
    }

    await loadDatabaseMatrices();
  };

  const handleResolveLeave = async (id: string, action: "Approved" | "Rejected") => {
    const res = await fetch(`/api/leaves/${id}/resolve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || "Approval authorization transaction halted.");
    }

    await loadDatabaseMatrices();
  };

  const handleMarkNotificationRead = async (id: string) => {
    const res = await fetch(`/api/notifications/${id}/read`, {
      method: "POST",
    });

    if (res.ok) {
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
    }
  };

  const handleNavigateToTab = (tab: string) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  const handleSelectFlight = (flightId: string) => {
    setActiveTab("Dispatch");
    setSelectedFlightId(flightId);
  };

  const handleSwitchSession = (crew: Crew) => {
    setSession({
      id: `user-${crew.id}`,
      username: crew.username || crew.name.toLowerCase().replace(/[^a-z0-9]/g, ""),
      name: crew.name,
      role: "Crew",
      crewId: crew.id,
    });
    setActiveTab("Dashboard");
  };

  if (!session) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  // Count unread alerts for notification bubbles
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#020617] text-white flex font-sans relative overflow-hidden">
      {/* Visual background sky gradient lines and mesh spots */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/15 rounded-full blur-[130px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/15 rounded-full blur-[130px]"></div>
        <div className="absolute top-[20%] right-[10%] w-[35%] h-[35%] bg-cyan-500/10 rounded-full blur-[110px]"></div>
      </div>

      {/* Main Sidebar (for desktop) */}
      <aside className="hidden md:flex flex-col w-64 backdrop-blur-xl bg-white/5 border-r border-white/10 shrink-0 shadow-2xl relative z-20">
        {/* Sidebar Header */}
        <div className="p-5 border-b border-white/10 flex items-center gap-2.5">
          <div className="w-10 h-10 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center text-white rotate-45 transform shadow-lg shadow-blue-500/20">
            <Plane className="w-5.5 h-5.5 text-white -rotate-45" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight uppercase leading-none text-white">SKYFLOW <span className="font-light text-cyan-400">CREW</span></h1>
            <p className="text-[10px] uppercase tracking-[0.1em] opacity-40 leading-none mt-1">
              Skyline Airways
            </p>
          </div>
        </div>

        {/* User identification badge */}
        <div className="px-5 py-4 border-b border-white/10 bg-white/5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-slate-200">
              <UserIcon className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs font-bold truncate text-slate-100">{session.name}</h4>
              <p className="text-[10px] font-semibold text-cyan-400 leading-none mt-0.5 uppercase tracking-wider">
                {session.role}
              </p>
            </div>
          </div>
        </div>

        {/* Sidebar Nav links */}
        <nav className="flex-1 p-4 space-y-1.5">
          {/* Dashboard */}
          <button
            onClick={() => handleNavigateToTab("Dashboard")}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
              activeTab === "Dashboard"
                ? "bg-gradient-to-tr from-blue-500/20 to-cyan-500/30 text-cyan-400 border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
                : "text-slate-300 border-transparent hover:bg-white/5 hover:text-white"
            }`}
          >
            <Calendar className="w-4.5 h-4.5" />
            Dashboard Home
          </button>

          {/* Roster database (Visible to Admin only) */}
          {session.role === "Admin" && (
            <button
              onClick={() => handleNavigateToTab("Crew")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
                activeTab === "Crew"
                  ? "bg-gradient-to-tr from-blue-500/20 to-cyan-500/30 text-cyan-400 border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
                  : "text-slate-300 border-transparent hover:bg-white/5 hover:text-white"
              }`}
            >
              <Users className="w-4.5 h-4.5" />
              Crew Database
            </button>
          )}

          {/* Dispatch Rotations (Visible to all) */}
          <button
            onClick={() => handleNavigateToTab("Dispatch")}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
              activeTab === "Dispatch"
                ? "bg-gradient-to-tr from-blue-500/20 to-cyan-500/30 text-cyan-400 border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
                : "text-slate-300 border-transparent hover:bg-white/5 hover:text-white"
            }`}
          >
            <Plane className="w-4.5 h-4.5" />
            Flight Dispatch
          </button>

          {/* Time Off Planner */}
          <button
            onClick={() => handleNavigateToTab("Leaves")}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all border ${
              activeTab === "Leaves"
                ? "bg-gradient-to-tr from-blue-500/20 to-cyan-500/30 text-cyan-400 border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.15)]"
                : "text-slate-300 border-transparent hover:bg-white/5 hover:text-white"
            }`}
          >
            <FileText className="w-4.5 h-4.5" />
            Time-Off Registry
          </button>

          {/* AI Optimizer Co-Pilot (Visible to Admin only) */}
          {session.role === "Admin" && (
            <button
              onClick={() => handleNavigateToTab("AI Co-Pilot")}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-extrabold cursor-pointer transition-all border ${
                activeTab === "AI Co-Pilot"
                  ? "bg-gradient-to-tr from-indigo-500/25 to-pink-500/30 text-pink-400 border-pink-500/20 shadow-[0_0_15px_rgba(236,72,153,0.15)]"
                  : "text-slate-300 border-transparent hover:bg-white/5 hover:text-white"
              }`}
            >
              <Sparkles className="w-4.5 h-4.5 text-cyan-400" />
              AI Dispatch Optimizer
            </button>
          )}
        </nav>

        {/* Footer actions */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold text-red-400 hover:bg-red-500/10 transition-all cursor-pointer text-left"
          >
            <LogOut className="w-4.5 h-4.5" />
            Terminate Session
          </button>
        </div>
      </aside>

      {/* Main content viewport */}
      <div className="flex-1 flex flex-col min-w-0 relative z-10">
        {/* Top Header Navbar */}
        <header className="backdrop-blur-xl bg-white/5 border-b border-white/10 px-5 py-3.5 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-1.5 rounded-lg bg-white/5 border border-white/10 text-white cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="md:hidden font-extrabold tracking-tight text-sm text-white flex items-center gap-2">
              <span className="w-6 h-6 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center text-white rotate-45 transform">
                <Plane className="w-4 h-4 text-white -rotate-45" />
              </span>
              SKYFLOW
            </h1>
            <span className="hidden md:inline-block text-xs font-medium text-slate-300/85">
              Skyflow Operations &bull; Global Roster Scheduler
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Global API Connection alert */}
            {dataError && (
              <span className="text-[10px] bg-red-500/15 text-red-400 px-2 py-0.5 rounded border border-red-500/30 font-bold font-mono">
                Roster Offline
              </span>
            )}

            {/* Notification alert count item */}
            <div className="relative">
              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="p-2 text-slate-300 hover:text-white bg-white/5 border border-white/10 rounded-xl transition-all relative cursor-pointer"
              >
                <Bell className="w-4.5 h-4.5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[9px] font-extrabold rounded-full flex items-center justify-center animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notificationsOpen && (
                <div className="absolute top-full right-0 mt-3 w-80 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden">
                  <div className="p-3 border-b border-white/10 bg-white/5 flex justify-between items-center">
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">Alerts & Notifications</h3>
                    <button onClick={() => setNotificationsOpen(false)} className="text-slate-400 hover:text-white cursor-pointer"><X className="w-4 h-4" /></button>
                  </div>
                  <div className="max-h-72 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-6 text-center text-slate-400 text-xs">No pending notifications</div>
                    ) : (
                      notifications.slice(0).reverse().map((notif) => (
                        <div key={notif.id} className={`p-4 border-b border-white/5 last:border-b-0 ${notif.read ? "opacity-50" : "bg-white/[0.02]"}`}>
                          <div className="flex gap-3">
                            <div className="mt-0.5 shrink-0">
                              {notif.severity === "error" ? <AlertTriangle className="w-4 h-4 text-red-400" /> : <Bell className="w-4 h-4 text-cyan-400" />}
                            </div>
                            <div>
                              <h4 className="text-xs font-bold text-white">{notif.title}</h4>
                              <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{notif.message}</p>
                              {!notif.read && (
                                <button
                                  onClick={() => handleMarkNotificationRead(notif.id)}
                                  className="mt-2 text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
                                >
                                  <CheckCircle className="w-3 h-3" /> Mark as Read
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Mobile Flyout Menu Overlay */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-[#020617]/90 backdrop-blur-md flex justify-start">
            <div className="w-64 bg-[#020617] border-r border-white/10 text-white p-5 space-y-6 relative flex flex-col justify-between">
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-6">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center text-white rotate-45 transform">
                    <Plane className="w-5 h-5 text-white -rotate-45" />
                  </div>
                  <h1 className="font-extrabold tracking-tight text-sm text-white">SKYFLOW CREW</h1>
                </div>

                <div className="p-3 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-slate-200">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-100 truncate">{session.name}</h4>
                    <p className="text-[10px] font-semibold text-cyan-400 leading-none mt-0.5 uppercase">
                      {session.role}
                    </p>
                  </div>
                </div>

                 <nav className="space-y-2">
                  <button
                    onClick={() => handleNavigateToTab("Dashboard")}
                    className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-left cursor-pointer border ${
                      activeTab === "Dashboard" ? "bg-white/10 text-cyan-400 border-white/10" : "text-slate-400 border-transparent hover:bg-white/5"
                    }`}
                  >
                    <Calendar className="w-4 h-4" /> Dashboard Home
                  </button>

                  {session.role === "Admin" && (
                    <button
                      onClick={() => handleNavigateToTab("Crew")}
                      className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-left cursor-pointer border ${
                        activeTab === "Crew" ? "bg-white/10 text-cyan-400 border-white/10" : "text-slate-400 border-transparent hover:bg-white/5"
                      }`}
                    >
                      <Users className="w-4.5 h-4.5" /> Crew Database
                    </button>
                  )}

                  <button
                    onClick={() => handleNavigateToTab("Dispatch")}
                    className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-left cursor-pointer border ${
                      activeTab === "Dispatch" ? "bg-white/10 text-cyan-400 border-white/10" : "text-slate-400 border-transparent hover:bg-white/5"
                    }`}
                  >
                    <Plane className="w-4 h-4" /> Flight Dispatch
                  </button>

                  <button
                    onClick={() => handleNavigateToTab("Leaves")}
                    className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-left cursor-pointer border ${
                      activeTab === "Leaves" ? "bg-white/10 text-cyan-400 border-white/10" : "text-slate-400 border-transparent hover:bg-white/5"
                    }`}
                  >
                    <FileText className="w-4 h-4" /> Time-Off Registry
                  </button>

                  {session.role === "Admin" && (
                    <button
                      onClick={() => handleNavigateToTab("AI Co-Pilot")}
                      className={`w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-left cursor-pointer border ${
                        activeTab === "AI Co-Pilot" ? "bg-white/10 text-cyan-400 border-white/10" : "text-slate-400 border-transparent hover:bg-white/5"
                      }`}
                    >
                      <Sparkles className="w-4 h-4 text-cyan-400" /> AI Dispatch Optimizer
                    </button>
                  )}
                </nav>
              </div>

              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-2 rounded-xl text-xs font-bold text-red-00 hover:bg-red-500/10 cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> Terminate Session
              </button>
            </div>
          </div>
        )}

        {/* Primary Tab module viewer */}
        <main className="flex-1 p-5 overflow-y-auto">
          {activeTab === "Dashboard" && (
            <RosterDashboard
              crewList={crewList}
              flights={flights}
              leaves={leaves}
              notifications={notifications}
              onMarkNotificationRead={handleMarkNotificationRead}
              onNavigateToTab={handleNavigateToTab}
              onSelectFlight={handleSelectFlight}
              session={session}
              onUpdateCrew={handleUpdateCrew}
              onSwitchSession={handleSwitchSession}
            />
          )}

          {activeTab === "Crew" && (
            <CrewManagement
              crewList={crewList}
              flights={flights}
              onAddCrew={handleAddNewCrew}
              onUpdateCrew={handleUpdateCrew}
              onDeleteCrew={handleDeleteCrew}
              onAssignCrew={handleAssignCrew}
              currentUserRole={session.role}
            />
          )}

          {activeTab === "Dispatch" && (
            <FlightScheduling
              flights={flights}
              crewList={crewList}
              onAddFlight={handleAddNewFlight}
              onAssignCrew={handleAssignCrew}
              currentUserRole={session.role}
              selectedFlightId={selectedFlightId}
              onSelectFlight={(id) => setSelectedFlightId(id)}
              onClearSelectedFlight={() => setSelectedFlightId(undefined)}
              onSwitchSession={handleSwitchSession}
            />
          )}

          {activeTab === "Leaves" && (
            <LeaveRequests
              leaves={leaves}
              crewList={crewList}
              onAddNewLeave={handleAddNewLeave}
              onResolveLeave={handleResolveLeave}
              currentUserRole={session.role}
              linkCrewId={session.crewId}
            />
          )}

          {activeTab === "AI Co-Pilot" && <AICopilot />}
        </main>
      </div>
    </div>
  );
}
