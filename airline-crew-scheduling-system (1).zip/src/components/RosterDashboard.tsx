import React, { useMemo, useEffect, useRef } from "react";
import {
  Calendar,
  Users,
  Plane,
  FileText,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldAlert,
  CheckCircle,
  XCircle,
  Bell,
  Check,
  UserCircle
} from "lucide-react";
import { Crew, Flight, LeaveRequest, Notification, User as UserType } from "../types";
import * as d3 from "d3";
import CrewMessenger from "./CrewMessenger";

interface RosterDashboardProps {
  crewList: Crew[];
  flights: Flight[];
  leaves: LeaveRequest[];
  notifications: Notification[];
  session: UserType;
  onUpdateCrew: (id: string, updates: Partial<Crew>) => Promise<any>;
  onMarkNotificationRead: (id: string) => void;
  onNavigateToTab: (tab: string) => void;
  onSelectFlight: (flightId: string) => void;
  onSwitchSession?: (crew: Crew) => void;
}

export default function RosterDashboard({
  crewList,
  flights,
  leaves,
  notifications,
  session,
  onUpdateCrew,
  onMarkNotificationRead,
  onNavigateToTab,
  onSelectFlight,
  onSwitchSession,
}: RosterDashboardProps) {
  // Statistics Computations
  const stats = useMemo(() => {
    const totalFlights = flights.length;
    const activeCrew = crewList.filter((c) => c.status === "Active").length;
    const restingCrew = crewList.filter((c) => c.status === "Resting").length;
    const leavesPending = leaves.filter((l) => l.status === "Pending").length;

    // Compliance estimation: flights with complete staffing
    let fullyStaffedCount = 0;
    flights.forEach((f) => {
      const assigned = crewList.filter((c) => f.assignedCrewIds.includes(c.id));
      const pilots = assigned.filter((c) => c.role === "Pilot").length;
      const cabin = assigned.filter((c) => c.role === "Cabin Crew").length;
      if (pilots >= f.requiredPilots && cabin >= f.requiredCabinCrew) {
        fullyStaffedCount++;
      }
    });
    const staffingPercentage = totalFlights
      ? Math.round((fullyStaffedCount / totalFlights) * 100)
      : 100;

    return {
      totalFlights,
      activeCrew,
      restingCrew,
      leavesPending,
      staffingPercentage,
    };
  }, [crewList, flights, leaves]);

  // Priority notifications
  const unreadNotifications = useMemo(() => {
    return notifications.filter((n) => !n.read).slice(0, 4);
  }, [notifications]);

  // Current session crew profile
  const currentUserCrew = useMemo(() => {
    if (!session?.crewId) return null;
    return crewList.find((c) => c.id === session.crewId) || null;
  }, [session, crewList]);

  if (session?.role !== "Admin") {
    return (
      <div className="space-y-6 font-sans">
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Your Roster Portal</h2>
            <p className="text-xs text-slate-400 mt-1">
              Welcome, {session.name}. Manage your duty status, view assigned dispatches, and message crew.
            </p>
          </div>
          <div className="text-xs font-mono text-slate-300 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.4)]" />
            <span>Secure UTC Terminal</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Column 1: Personal Profile Description & Duty Info */}
          <div className="lg:col-span-5 space-y-6">
            {currentUserCrew ? (
              <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col items-center text-center space-y-4">
                <div className="w-20 h-20 bg-gradient-to-tr from-cyan-400 to-blue-500 rounded-full p-0.5 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
                  <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center">
                    <UserCircle className="w-10 h-10 text-cyan-400" />
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-bold text-white">{currentUserCrew.name}</h3>
                  <p className="text-[11px] text-cyan-400 uppercase tracking-wider font-semibold mt-1">
                    {currentUserCrew.role} • {currentUserCrew.baseAirport}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono mt-1">{currentUserCrew.rank}</p>
                </div>

                <div className="w-full space-y-3.5 pt-3 text-left border-t border-dashed border-white/10">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>Weekly Duty Load</span>
                    <span className="font-mono text-white font-bold">{currentUserCrew.flightHoursThisWeek} / {currentUserCrew.maxWeeklyHours} h</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) > 0.85 
                        ? "bg-gradient-to-r from-orange-400 to-red-500" 
                        : "bg-gradient-to-r from-emerald-400 to-cyan-400"
                      }`} 
                      style={{ width: `${Math.min(100, (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) * 100)}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <div className="bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Status</span>
                      <select
                        value={currentUserCrew.status}
                        onChange={async (e) => {
                          try {
                            await onUpdateCrew(currentUserCrew.id, { status: e.target.value as any });
                          } catch(err) {
                            alert("Failed to update status");
                          }
                        }}
                        className={`mt-1 bg-transparent text-xs font-bold outline-none cursor-pointer appearance-none text-center ${
                          currentUserCrew.status === 'Active' ? 'text-emerald-400' : currentUserCrew.status === 'Resting' ? 'text-indigo-400' : currentUserCrew.status === 'Travelling' ? 'text-blue-400' : 'text-slate-300'
                        }`}
                      >
                        <option value="Active" className="bg-slate-950 text-emerald-400">Active</option>
                        <option value="Resting" className="bg-slate-950 text-indigo-400">Resting</option>
                        <option value="Travelling" className="bg-slate-950 text-blue-400">Travelling</option>
                        <option value="Standby" className="bg-slate-950 text-cyan-400">Standby</option>
                        <option value="On Leave" className="bg-slate-950 text-slate-400">On Leave</option>
                      </select>
                    </div>
                    <div className="bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center justify-center">
                      <span className="text-[10px] text-slate-450 font-bold uppercase tracking-wide">Primary Airport</span>
                      <span className="text-xs font-bold text-white mt-1 uppercase">
                        {currentUserCrew.baseAirport}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-white/5 border border-white/5 rounded-2xl text-[10px] space-y-1 text-slate-400">
                    <div className="flex justify-between">
                      <span>Corporate Email:</span>
                      <span className="text-slate-200 truncate">{currentUserCrew.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Registered Contact:</span>
                      <span className="text-slate-200 font-mono">{currentUserCrew.phone}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6 text-center text-slate-400 text-xs">
                Unable to locate personalized crew member record. Please contact administration.
              </div>
            )}
          </div>

          {/* Column 2: Communications Control & Assigned Flights block */}
          <div className="lg:col-span-7 space-y-6">
            {/* Crew Confidential Messenger Component */}
            <CrewMessenger session={session} crewList={crewList} />

            {/* Assigned Flight Schedule Card */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl">
              <h3 className="font-bold text-white text-sm mb-1">Your Block Flight Schedule</h3>
              <p className="text-xs text-slate-450 mb-4">Official rostered flights matching your active rotation.</p>

              <div className="space-y-3">
                {currentUserCrew ? (() => {
                  const myScheduledFlights = flights.filter(f => f.assignedCrewIds.includes(currentUserCrew.id));
                  if (myScheduledFlights.length === 0) {
                    return (
                      <p className="text-[11px] text-slate-450 text-center py-4">No rostered flights scheduled on this block.</p>
                    );
                  }
                  return myScheduledFlights.map(flight => {
                    const flightCrew = crewList.filter(c => flight.assignedCrewIds.includes(c.id));
                    return (
                      <div key={flight.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-cyan-400">{flight.flightNumber}</span>
                              <span className="text-[9px] font-mono text-slate-400 bg-white/5 px-1 py-0.5 rounded">{flight.aircraftType}</span>
                            </div>
                            <div className="text-[11px] font-medium text-slate-300 mt-1 flex items-center gap-1">
                              <span>{flight.origin}</span>
                              <span>→</span>
                              <span>{flight.destination}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-mono text-white font-semibold flex items-center gap-1 justify-end">
                              <Clock className="w-3" />
                              {new Date(flight.departureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', timeZone: 'UTC' })}
                            </span>
                            <p className="text-[9px] text-slate-450">Departure UTC</p>
                          </div>
                        </div>

                        {/* Crew Details with multi-profile switching */}
                        <div className="pt-2 border-t border-white/5 space-y-2">
                          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Flight Staff Assigned:</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {flightCrew.map(crew => {
                              const isSelf = crew.id === currentUserCrew.id;
                              return (
                                <div key={crew.id} className="flex items-center justify-between bg-white/[0.03] border border-white/5 p-2 rounded-xl text-[10px]">
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <div className={`w-5 h-5 rounded-md flex items-center justify-center text-[9px] font-bold text-white shrink-0 ${crew.avatarColor}`}>
                                      {crew.name.split(" ").pop()?.charAt(0)}
                                    </div>
                                    <div className="truncate">
                                      <p className="text-white font-bold truncate">{crew.name}</p>
                                      <p className="text-[8px] text-slate-450">{crew.role}</p>
                                    </div>
                                  </div>
                                  {!isSelf && onSwitchSession && (
                                    <button
                                      type="button"
                                      onClick={() => onSwitchSession(crew)}
                                      className="py-1 px-2 font-extrabold text-[9px] bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-500/20 text-cyan-400 hover:text-white rounded-lg transition-all cursor-pointer"
                                    >
                                      Switch Session
                                    </button>
                                  )}
                                  {isSelf && (
                                    <span className="text-[8px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 rounded px-1.5 py-0.5">
                                      Active Self
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    );
                  });
                })() : null}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Roster Control Board</h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time visual monitoring of corporate flight dispatches and regulatory safety checks.
          </p>
        </div>
        <div className="text-xs font-mono text-slate-300 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.4)]" />
          <span>System UTC: 2026-05-27 20:03</span>
        </div>
      </div>

      {/* Stats Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Flights */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/20 flex items-center justify-center">
            <Plane className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Scheduled Slots</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.totalFlights} Flights</h3>
          </div>
        </div>

        {/* Active Crew */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20 flex items-center justify-center">
            <Users className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">On-Duty Crew</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.activeCrew} Active</h3>
          </div>
        </div>

        {/* Resting Standby */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-indigo-500/10 text-indigo-300 rounded-xl border border-indigo-500/20 flex items-center justify-center">
            <Clock className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Resting Standby</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.restingCrew} Crew</h3>
          </div>
        </div>

        {/* Leave Requests */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl flex items-center gap-4 hover:border-white/20 hover:bg-white/8 transition-all">
          <div className="w-11 h-11 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20 flex items-center justify-center font-bold">
            <FileText className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-450 uppercase tracking-wider">Pending Leaves</p>
            <h3 className="text-xl font-bold text-white mt-0.5">{stats.leavesPending} Petitions</h3>
          </div>
        </div>

        {/* Staffing Health Rate */}
        <div className="backdrop-blur-xl bg-gradient-to-tr from-blue-500/20 to-cyan-500/20 border border-cyan-500/30 p-5 rounded-3xl flex items-center gap-4 shadow-lg hover:border-cyan-500/40 transition-all">
          <div className="w-11 h-11 bg-cyan-400/20 text-cyan-300 rounded-xl flex items-center justify-center">
            <ShieldAlert className="w-5.5 h-5.5" />
          </div>
          <div>
            <p className="text-[10px] font-semibold text-slate-350 uppercase tracking-wide">Staffing Level</p>
            <h3 className="text-xl font-extrabold text-cyan-400 mt-0.5">{stats.staffingPercentage}%</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Personal Profile Section */}
        {currentUserCrew && (
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-6 shadow-xl xl:col-span-1 flex flex-col items-center text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-tr from-cyan-400 to-blue-500 rounded-full p-0.5 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
              <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center">
                <UserCircle className="w-10 h-10 text-cyan-400" />
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-bold text-white">{currentUserCrew.name}</h3>
              <p className="text-[11px] text-cyan-400 uppercase tracking-wider font-semibold mt-1">
                {currentUserCrew.role} • {currentUserCrew.baseAirport}
              </p>
            </div>

            <div className="w-full max-w-xs space-y-3 pt-3">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Duty Hours This Week</span>
                <span className="font-mono text-white font-bold">{currentUserCrew.flightHoursThisWeek} / {currentUserCrew.maxWeeklyHours} h</span>
              </div>
              <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all ${
                    (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) > 0.85 
                    ? "bg-gradient-to-r from-orange-400 to-red-500" 
                    : "bg-gradient-to-r from-emerald-400 to-cyan-400"
                  }`} 
                  style={{ width: `${Math.min(100, (currentUserCrew.flightHoursThisWeek / currentUserCrew.maxWeeklyHours) * 100)}%` }}
                />
              </div>
              
              <div className="flex gap-2 w-full pt-2">
                <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center relative group">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wide">Status</span>
                  <select
                    value={currentUserCrew.status}
                    onChange={async (e) => {
                      try {
                        await onUpdateCrew(currentUserCrew.id, { status: e.target.value as any });
                      } catch(err) {
                        alert("Failed to update status");
                      }
                    }}
                    className={`mt-1 text-xs font-bold bg-transparent outline-none cursor-pointer appearance-none text-center ${currentUserCrew.status === 'Active' ? 'text-emerald-400' : currentUserCrew.status === 'Resting' ? 'text-indigo-400' : currentUserCrew.status === 'Travelling' ? 'text-blue-400' : 'text-slate-400'}`}
                  >
                    <option value="Active" className="bg-slate-900 text-emerald-400">Active</option>
                    <option value="Resting" className="bg-slate-900 text-indigo-400">Resting</option>
                    <option value="Travelling" className="bg-slate-900 text-blue-400">Travelling</option>
                    <option value="Standby" className="bg-slate-900 text-amber-400">Standby</option>
                    <option value="On Leave" className="bg-slate-900 text-slate-400">On Leave</option>
                  </select>
                </div>
                <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl flex flex-col items-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wide">Flights</span>
                  <span className="text-xs font-bold text-slate-200 mt-1">
                    {flights.filter(f => f.assignedCrewIds.includes(currentUserCrew.id)).length} Active
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Heatmap Section */}
        <div className={`backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl ${currentUserCrew ? 'xl:col-span-3' : 'xl:col-span-4'}`}>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-white">Duty Hours Visualizer (D3 Heatmap)</h3>
          </div>
          <p className="text-xs text-slate-400 mb-6">
            Real-time visualization of accumulated duty hours across team personnel. Red markers indicate max regulatory allowable hours per week.
          </p>
          <RosterHeatmap crewList={crewList} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Gantt Area */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-cyan-400 drop-shadow-[0_0_4px_rgba(34,211,238,0.3)]" />
              <h3 className="font-bold text-white">Flight Rotation Timeline</h3>
            </div>
            <span className="text-[10px] font-bold bg-white/10 text-slate-300 px-2 py-1 rounded-md uppercase border border-white/5">
              May 28 - May 29
            </span>
          </div>

          <div className="space-y-3">
            {flights.map((flight) => {
              const assignedCount = flight.assignedCrewIds.length;
              const isStaffed =
                flight.assignedCrewIds.filter(
                  (cid) => crewList.find((c) => c.id === cid)?.role === "Pilot"
                ).length >= flight.requiredPilots &&
                flight.assignedCrewIds.filter(
                  (cid) => crewList.find((c) => c.id === cid)?.role === "Cabin Crew"
                ).length >= flight.requiredCabinCrew;

              return (
                <div
                  key={flight.id}
                  className="p-4 bg-white/[0.02] border border-white/5 hover:border-white/15 hover:bg-white/5 rounded-2xl transition-all cursor-pointer"
                  onClick={() => onSelectFlight(flight.id)}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 bg-cyan-400/10 border border-cyan-400/20 rounded-xl flex items-center justify-center font-bold text-xs text-cyan-400 shadow-md">
                        {flight.flightNumber.split("-")[1] || flight.flightNumber}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white text-sm">
                            {flight.flightNumber}
                          </span>
                          <span className="text-[10px] font-semibold bg-white/10 text-slate-300 px-1.5 py-0.5 rounded">
                            {flight.aircraftType}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                          <span className="font-semibold text-slate-200">{flight.origin}</span>
                          <ArrowRight className="w-3 h-3 text-cyan-400/60" />
                          <span className="font-semibold text-slate-200">{flight.destination}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {/* Timeline clock bar */}
                      <div className="text-right">
                        <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5 justify-end">
                          <Clock className="w-3" />
                          <span>
                            {new Date(flight.departureTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                              timeZone: "UTC",
                            })}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400">Scheduled Departure UTC</span>
                      </div>

                      {/* Staffing indicator */}
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <span
                            className={`text-xs font-bold ${
                              isStaffed ? "text-emerald-400" : "text-amber-400"
                            }`}
                          >
                            {assignedCount} Crew
                          </span>
                          <div className="text-[10px] text-slate-400">
                            Req: {flight.requiredPilots}P/{flight.requiredCabinCrew}C
                          </div>
                        </div>
                        <div>
                          {isStaffed ? (
                            <div className="w-5 h-5 bg-emerald-500/15 text-emerald-400 rounded-full flex items-center justify-center border border-emerald-500/25">
                              <CheckCircle className="w-3.5 h-3.5" />
                            </div>
                          ) : (
                            <div className="w-5 h-5 bg-amber-500/15 text-amber-400 rounded-full flex items-center justify-center border border-amber-500/25">
                              <AlertTriangle className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Gantt progress visual bar */}
                  <div className="mt-3.5 w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        isStaffed ? "bg-gradient-to-r from-emerald-500 to-teal-400" : "bg-gradient-to-r from-amber-500 to-orange-400"
                      }`}
                      style={{
                        width: `${Math.min(
                          (assignedCount / (flight.requiredPilots + flight.requiredCabinCrew)) * 100,
                          100
                        )}%`,
                      }}
                    />
                  </div>

                  {/* Flight Crew Assigned Row with Switch Session buttons */}
                  <div className="mt-3 pt-3 border-t border-white/5 flex flex-wrap gap-2 items-center">
                    <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">Flight Staff Assigned:</span>
                    {crewList.filter((c) => flight.assignedCrewIds.includes(c.id)).length === 0 ? (
                      <span className="text-[9px] text-slate-500 italic">No assigned personnel</span>
                    ) : (
                      crewList
                        .filter((c) => flight.assignedCrewIds.includes(c.id))
                        .map((crew) => {
                          const isCurrentActive = crew.id === currentUserCrew?.id;
                          return (
                            <div 
                              key={crew.id} 
                              onClick={(e) => e.stopPropagation()} // Prevent clicking parent card which selects flight
                              className={`flex items-center gap-1 bg-white/[0.02] hover:bg-white/5 border border-white/5 p-1 px-1.5 rounded-lg text-[9px] ${
                                isCurrentActive ? "border-cyan-400/20 text-cyan-300 animate-pulse" : "text-slate-300"
                              }`}
                            >
                              <span className="font-bold">{crew.name}</span>
                              <span className="text-slate-500 text-[8px] font-medium font-mono">({crew.role.split(" ")[0]})</span>
                              {onSwitchSession && !isCurrentActive && (
                                <button
                                  type="button"
                                  onClick={() => onSwitchSession(crew)}
                                  className="ml-1 bg-cyan-400/10 hover:bg-cyan-400/25 border border-cyan-400/20 text-cyan-400 hover:text-white px-1.5 py-0.5 rounded transition-all cursor-pointer font-bold text-[8px]"
                                >
                                  Log In
                                </button>
                              )}
                              {isCurrentActive && (
                                <span className="ml-1 text-[7px] text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 rounded px-0.5">Self</span>
                              )}
                            </div>
                          );
                        })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Notifications & System Updates sidebar */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-cyan-400" />
              <h3 className="font-bold text-white">Operational Alerts</h3>
            </div>
            {unreadNotifications.length > 0 && (
              <span className="bg-red-500/20 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/25 animate-pulse">
                {unreadNotifications.length} New
              </span>
            )}
          </div>

          <div className="space-y-3 font-sans">
            {unreadNotifications.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <CheckCircle className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                <p className="text-xs">No active conflicts detected.</p>
                <p className="text-[10px] text-slate-500 mt-1">Schedules comply with legal rest hours.</p>
              </div>
            ) : (
              unreadNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-3 rounded-xl border flex items-start gap-2.5 transition-all ${
                    notif.severity === "error"
                      ? "bg-red-500/10 border-red-500/20"
                      : notif.severity === "warning"
                      ? "bg-amber-500/10 border-amber-500/20"
                      : "bg-cyan-500/10 border-cyan-500/20"
                  }`}
                >
                  <div className="mt-0.5 shrink-0">
                    {notif.severity === "error" ? (
                      <XCircle className="w-4 h-4 text-red-400" />
                    ) : notif.severity === "warning" ? (
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-cyan-400" />
                    )}
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-xs font-bold text-slate-155 text-white">{notif.title}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onMarkNotificationRead(notif.id);
                        }}
                        className="p-0.5 hover:bg-white/10 border border-white/5 hover:border-white/20 rounded text-slate-400 hover:text-white transition-all cursor-pointer"
                        title="Dismiss alert"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed font-sans">{notif.message}</p>
                    <div className="text-[9px] text-slate-500 mt-1 uppercase tracking-wider font-semibold font-mono">
                      {new Date(notif.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button
            onClick={() => onNavigateToTab("Dispatch")}
            className="w-full py-2.5 bg-white/5 hover:bg-white/10 hover:text-cyan-400 border border-white/10 rounded-xl text-xs font-bold text-slate-200 text-center block transition-all hover:shadow-lg cursor-pointer"
          >
            Review Staff Assignments &rarr;
          </button>
        </div>
      </div>
    </div>
  );
}

interface RosterHeatmapProps {
  crewList: Crew[];
}

function RosterHeatmap({ crewList }: RosterHeatmapProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !crewList.length) return;

    const width = 800;
    const height = Math.max(300, crewList.length * 30 + 60);
    const margin = { top: 30, right: 30, bottom: 30, left: 150 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Clear previous SVG contents
    d3.select(svgRef.current).selectAll("*").remove();

    const svg = d3
      .select(svgRef.current)
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("width", "100%")
      .attr("height", "100%");

    const g = svg
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // We visualize flight hours for current week across all crew.
    // X-axis: Hours (0 to 120 approx max)
    // Y-axis: Crew Members
    
    // X scale
    const x = d3.scaleLinear()
      .domain([0, d3.max(crewList, (d) => Math.max(60, d.flightHoursThisWeek)) || 60])
      .range([0, innerWidth]);

    // Y scale
    const y = d3.scaleBand()
      .domain(crewList.map(d => d.name))
      .range([0, innerHeight])
      .padding(0.2);

    // Color scale for intensity
    const colorScale = d3.scaleSequential()
      .domain([0, 60])
      .interpolator(d3.interpolatePuBuGn);

    // X Axis
    g.append("g")
      .attr("transform", `translate(0,${innerHeight})`)
      .call(d3.axisBottom(x).ticks(10))
      .attr("color", "#94a3b8")
      .selectAll("text")
      .style("font-size", "10px")
      .style("font-family", "sans-serif");

    // Y Axis
    g.append("g")
      .call(d3.axisLeft(y).tickSize(0))
      .attr("color", "#cbd5e1")
      .selectAll("text")
      .style("font-size", "11px")
      .style("font-family", "sans-serif")
      .attr("dx", "-10");

    // Bars/Heatmap items
    g.selectAll(".bar")
      .data(crewList)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("y", d => y(d.name) || 0)
      .attr("height", y.bandwidth())
      .attr("x", 0)
      .attr("width", 0) // Start at zero for animation
      .attr("fill", d => {
        if (d.flightHoursThisWeek >= d.maxWeeklyHours * 0.85) {
          return "#ef4444"; // red-500
        }
        return colorScale(d.flightHoursThisWeek) as string;
      })
      .attr("rx", 4)
      .transition()
      .duration(1000)
      .ease(d3.easeCubicOut)
      .attr("width", d => x(d.flightHoursThisWeek));

    // Data labels on bars
    g.selectAll(".label")
      .data(crewList)
      .enter()
      .append("text")
      .attr("class", "label")
      .attr("y", d => (y(d.name) || 0) + y.bandwidth() / 2)
      .attr("x", 0) // Start at 0 for animation sync
      .attr("dy", "0.35em")
      .attr("dx", "5")
      .attr("fill", "#0f172a")
      .style("font-size", "10px")
      .style("font-weight", "bold")
      .style("opacity", 0)
      .text(d => `${d.flightHoursThisWeek}h`)
      .transition()
      .duration(1000)
      .ease(d3.easeCubicOut)
      .attr("x", d => x(d.flightHoursThisWeek))
      .style("opacity", 1);
      
    // Max Weekly limit line
    g.selectAll(".limit-line")
      .data(crewList)
      .enter()
      .append("line")
      .attr("x1", d => x(d.maxWeeklyHours))
      .attr("x2", d => x(d.maxWeeklyHours))
      .attr("y1", d => y(d.name) || 0)
      .attr("y2", d => (y(d.name) || 0) + y.bandwidth())
      .attr("stroke", "#ef4444") // Red limit line
      .attr("stroke-width", 2)
      .attr("stroke-dasharray", "2,2")
      .style("opacity", 0)
      .transition()
      .duration(1000)
      .style("opacity", 1);

  }, [crewList]);

  return (
    <div className="w-full overflow-x-auto overflow-y-hidden">
      <svg ref={svgRef}></svg>
    </div>
  );
}
