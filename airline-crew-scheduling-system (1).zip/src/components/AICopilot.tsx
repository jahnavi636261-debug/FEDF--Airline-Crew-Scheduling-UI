import React, { useState, useEffect, useMemo } from "react";
import { motion } from "motion/react";
import {
  Sparkles,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  Lightbulb,
  ShieldCheck,
  CheckCircle,
  HelpCircle,
  Clock,
  PieChart
} from "lucide-react";

interface Violation {
  flight: string;
  description: string;
  severity: "high" | "medium" | "low";
}

interface Recommendation {
  title: string;
  detail: string;
}

interface AICopilotData {
  optimized: boolean;
  summary: string;
  violations?: Violation[];
  recommendations?: Recommendation[];
  metrics?: {
    totalStaff: number;
    utilizationRatePercent: number;
    fullyStaffedPercentage: number;
  };
}

export default function AICopilot() {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AICopilotData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingStep, setLoadingStep] = useState(0);

  // Derive robust Efficiency Score based on underlying health stats
  const efficiencyScore = useMemo(() => {
    if (!data) return 0;
    const utilization = data.metrics?.utilizationRatePercent ?? 75;
    const staffing = data.metrics?.fullyStaffedPercentage ?? 80;
    const violationPenalty = (data.violations?.length ?? 0) * 12;

    // Utilization is optimal around 75%. Calculate deviation from 75%.
    const utilizationDeviation = Math.abs(utilization - 75);
    const utilizationScore = Math.max(0, 100 - utilizationDeviation * 2.5);

    const rawScore = (staffing * 0.6) + (utilizationScore * 0.4) - violationPenalty;
    return Math.max(10, Math.min(100, Math.round(rawScore)));
  }, [data]);

  const scoreConfig = useMemo(() => {
    if (efficiencyScore >= 85) {
      return {
        text: "OPTI-SAFE",
        desc: "Roster has outstanding capacity, ample crew rest, and full safety coverage.",
        textColor: "text-emerald-400",
        strokeColor: "url(#green-gradient)",
        badgeColor: "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400",
      };
    } else if (efficiencyScore >= 65) {
      return {
        text: "SECURE / STABLE",
        desc: "Roster is operational, but standby reallocation is advised for high duty limits.",
        textColor: "text-amber-400",
        strokeColor: "url(#amber-gradient)",
        badgeColor: "bg-amber-500/10 border border-amber-500/20 text-amber-400",
      };
    } else {
      return {
        text: "OVERBURDENED",
        desc: "Operational warnings detected. Active staffing gaps require urgent dispatch action.",
        textColor: "text-rose-400",
        strokeColor: "url(#red-gradient)",
        badgeColor: "bg-rose-500/15 border border-rose-500/20 text-rose-400",
      };
    }
  }, [efficiencyScore]);

  const loadingMessages = [
    "Compiling active crew data matrices...",
    "Validating airline duty limits and rest patterns...",
    "Querying Gemini 3.5 dispatch optimization kernels...",
    "Structuring compliance resolutions...",
  ];

  // Cycling reassurance loading texts
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev + 1) % loadingMessages.length);
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleRunAnalysis = async () => {
    setLoading(true);
    setError(null);
    setLoadingStep(0);

    try {
      const response = await fetch("/api/ai/analyze");
      if (!response.ok) {
        throw new Error("Could not acquire connection to dispatch services.");
      }
      const report: AICopilotData = await response.json();
      setData(report);
    } catch (err: any) {
      setError(err.message || "Failed to finalize roster optimization modeling.");
    } finally {
      setLoading(false);
    }
  };

  // Run initial analysis automatically on visit
  useEffect(() => {
    handleRunAnalysis();
  }, []);

  return (
    <div className="space-y-6 font-sans">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-cyan-400">
              <Sparkles className="w-4.5 h-4.5 animate-pulse" />
            </div>
            <h2 className="text-xl font-extrabold text-white tracking-tight">AI Dispatch Co-Pilot</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            Perform instant predictive audits for FAA duty-limit compliance and receive automated crew placement recommendations.
          </p>
        </div>
        <button
          onClick={handleRunAnalysis}
          disabled={loading}
          className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 disabled:opacity-50 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg shadow-cyan-500/10 hover:shadow-cyan-500/20 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2 shrink-0 self-start sm:self-center"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Compile Roster Analysis
        </button>
      </div>

      {loading ? (
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl py-16 flex flex-col items-center justify-center space-y-4 max-w-lg mx-auto shadow-xl">
          <div className="relative">
            <div className="w-14 h-14 border-4 border-white/10 border-t-cyan-500 rounded-full animate-spin" />
            <Sparkles className="w-5 h-5 text-cyan-400 absolute inset-0 m-auto animate-pulse" />
          </div>
          <div className="text-center space-y-1.5 px-6 font-sans">
            <h4 className="font-extrabold text-sm text-white">Simulating Staff Rotations</h4>
            <p className="text-xs text-slate-400 animate-pulse font-medium">{loadingMessages[loadingStep]}</p>
          </div>
        </div>
      ) : error ? (
        <div className="backdrop-blur-md bg-red-500/10 border border-red-500/20 rounded-3xl p-6 text-center text-red-200 space-y-4 max-w-md mx-auto">
          <AlertTriangle className="w-10 h-10 text-red-400 mx-auto animate-bounce" />
          <div className="space-y-1 font-sans">
            <h4 className="font-bold text-sm text-white">Roster Analysis Halted</h4>
            <p className="text-xs text-red-200 leading-relaxed font-sans">{error}</p>
          </div>
          <button
            onClick={handleRunAnalysis}
            className="px-4 py-2 hover:bg-white/10 border border-white/10 font-bold text-xs rounded-xl text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            Retry Execution
          </button>
        </div>
      ) : data ? (
        <div className="space-y-6">
          {/* Executive Overview cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Column 1: Health Assessment */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl shadow-xl flex flex-col justify-between space-y-4">
              <div className="space-y-3.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4.5 h-4.5 text-cyan-400" />
                  <h3 className="font-extrabold text-white text-sm">Roster Health Assessment</h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed bg-white/[0.015] p-4 border border-white/5 rounded-2xl font-sans font-medium overflow-y-auto max-h-[120px]">
                  {data.summary}
                </p>
              </div>

              {data.metrics && (
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="bg-white/[0.02] border border-white/5 p-3 rounded-2xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500">Database Size</span>
                    <h4 className="text-sm font-bold text-white font-mono mt-1">
                      {data.metrics.totalStaff} Crew
                    </h4>
                  </div>
                  <div className="bg-white/[0.02] border border-white/5 p-3 rounded-2xl">
                    <span className="text-[9px] uppercase font-bold text-slate-500">Schedule Status</span>
                    <h4 className="text-sm font-bold text-emerald-400 font-mono mt-1">
                      {data.metrics.fullyStaffedPercentage}% Clean
                    </h4>
                  </div>
                </div>
              )}
            </div>

            {/* Column 2: Visual 'Efficiency Score' Gauge */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl shadow-xl flex flex-col justify-between space-y-4">
              <div className="space-y-3 font-sans">
                <div className="flex items-center gap-2 text-white">
                  <TrendingUp className="w-4.5 h-4.5 text-cyan-400" />
                  <h3 className="font-extrabold text-white text-sm">Staffing Efficiency Index</h3>
                </div>
                <p className="text-[11px] text-slate-400 leading-normal font-sans font-medium">
                  Dynamic calculations modeling current safety capacity against crew workload limits.
                </p>
              </div>

              {/* Animated Semicircle or Circular Gauge Container */}
              <div className="flex flex-col items-center justify-center py-2 relative">
                <div className="relative w-32 h-32 flex items-center justify-center">
                  <svg className="w-28 h-28 transform -rotate-90 filter drop-shadow-[0_0_10px_rgba(6,182,212,0.1)]" viewBox="0 0 100 100">
                    <defs>
                      <linearGradient id="green-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#10b981" />
                        <stop offset="100%" stopColor="#06b6d4" />
                      </linearGradient>
                      <linearGradient id="amber-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#f59e0b" />
                        <stop offset="100%" stopColor="#f97316" />
                      </linearGradient>
                      <linearGradient id="red-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#ef4444" />
                        <stop offset="100%" stopColor="#f43f5e" />
                      </linearGradient>
                    </defs>
                    {/* Track */}
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="rgba(255, 255, 255, 0.05)"
                      strokeWidth="8"
                      fill="transparent"
                    />
                    {/* Animated Progress Ring */}
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke={scoreConfig.strokeColor}
                      strokeWidth="8"
                      fill="transparent"
                      strokeDasharray="251.2"
                      initial={{ strokeDashoffset: 251.2 }}
                      animate={{ strokeDashoffset: 251.2 - (efficiencyScore / 100) * 251.2 }}
                      transition={{ duration: 1.5, ease: "easeOut" }}
                      strokeLinecap="round"
                    />
                  </svg>
                  {/* Score Label inside Ring */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center font-sans">
                    <motion.span
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: 0.3, duration: 0.5 }}
                      className={`text-2xl font-black tracking-tight font-mono ${scoreConfig.textColor}`}
                    >
                      {efficiencyScore}%
                    </motion.span>
                    <span className="text-[8px] uppercase font-bold text-slate-500 tracking-wider mt-0.5">HEALTH</span>
                  </div>
                </div>

                {/* Status indicator badge */}
                <span className={`text-[9px] uppercase font-black px-2.5 py-0.5 rounded border inline-block mt-3 text-center self-center transition-all ${scoreConfig.badgeColor}`}>
                  {scoreConfig.text}
                </span>
              </div>

              {/* Short summary text */}
              <div className="text-[10px] text-slate-400 text-center font-sans font-medium leading-relaxed border-t border-white/5 pt-3">
                {scoreConfig.desc}
              </div>
            </div>

            {/* Column 3: Regulatory Roster Audits */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl shadow-xl flex flex-col justify-between">
              <div className="space-y-3.5 font-sans">
                <div className="flex items-center gap-2 text-white">
                  <PieChart className="w-4.5 h-4.5 text-cyan-400" />
                  <h3 className="font-extrabold text-white text-sm">Regulatory Roster Audits</h3>
                </div>
                <p className="text-[11px] text-slate-400 leading-normal font-sans font-medium">
                  Continuous evaluation of pilot flight ranges and rest rules, keeping track of overlapping dispatches.
                </p>
              </div>

              {/* Mini visual chart display */}
              <div className="space-y-3 mt-4 font-sans">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>Duty Compliance</span>
                  <span className="text-white font-mono font-bold">100% compliant</span>
                </div>
                <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full rounded-full" style={{ width: "100%" }} />
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>Minimum Required Rest</span>
                  <span className="text-cyan-400 font-mono font-bold">10h Standard</span>
                </div>
                <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-450 h-full rounded-full" style={{ width: "100%" }} />
                </div>

                {data.metrics && (
                  <>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-white/5 mt-1.5">
                      <span>Roster Utility Factor</span>
                      <span className="text-cyan-400 font-mono font-bold">{data.metrics.utilizationRatePercent}% Active</span>
                    </div>
                    <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full rounded-full" style={{ width: `${data.metrics.utilizationRatePercent}%` }} />
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Risk Spotter Warnings Card */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl shadow-xl space-y-4">
              <div className="flex items-center gap-2 border-b border-white/10 pb-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 animate-pulse" />
                <h3 className="font-extrabold text-white text-sm">Identified Staffing Deficits</h3>
              </div>

              <div className="space-y-3 font-sans">
                {!data.violations || data.violations.length === 0 ? (
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded-2xl text-xs flex items-center gap-2.5">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span>Roster is fully staffed and complies with local airport regulations!</span>
                  </div>
                ) : (
                  data.violations.map((violation, idx) => (
                    <div
                      key={idx}
                      className={`p-3.5 border rounded-2xl space-y-1 ${
                        violation.severity === "high"
                          ? "bg-red-500/10 border-red-500/15"
                          : violation.severity === "medium"
                          ? "bg-amber-500/10 border-amber-500/15"
                          : "bg-white/[0.02] border-white/5"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">
                          {violation.flight}
                        </span>
                        <span
                          className={`text-[9px] uppercase font-extrabold px-2 py-0.5 rounded ${
                            violation.severity === "high"
                              ? "text-red-400 bg-red-500/15"
                              : violation.severity === "medium"
                              ? "text-amber-400 bg-amber-500/15"
                              : "text-slate-300 bg-white/10"
                          }`}
                        >
                          {violation.severity} hazard
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-normal font-sans">
                        {violation.description}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Smart recommendations instructions card */}
            <div className="backdrop-blur-xl bg-white/5 border border-white/10 p-5 rounded-3xl shadow-xl space-y-4">
              <div className="flex items-center gap-2 border-b border-white/10 pb-3">
                <Lightbulb className="w-5 h-5 text-cyan-400" />
                <h3 className="font-extrabold text-white text-sm">Smart Roster Solutions</h3>
              </div>

              <div className="space-y-3 font-sans">
                {!data.recommendations || data.recommendations.length === 0 ? (
                  <div className="p-4 text-center text-slate-400 text-xs">
                    No solutions required. Check database size values to verify crew availability.
                  </div>
                ) : (
                  data.recommendations.map((recommendation, idx) => (
                    <div key={idx} className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                      <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                        {recommendation.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-sans font-medium">
                        {recommendation.detail}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 text-slate-400">
          <Sparkles className="w-10 h-10 text-slate-655 mx-auto" />
          <p className="text-xs mt-2">AI evaluation services idle. Click Compile Roster Analysis above to begin.</p>
        </div>
      )}
    </div>
  );
}
