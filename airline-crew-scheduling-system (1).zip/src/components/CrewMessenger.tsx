import React, { useState, useEffect, useRef } from "react";
import { Send, MessageSquare, ArrowRightLeft, Clock, UserCheck, ShieldAlert } from "lucide-react";
import { Crew, User as UserType } from "../types";

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  content: string;
  timestamp: string;
}

interface CrewMessengerProps {
  session: UserType;
  crewList: Crew[];
}

export default function CrewMessenger({ session, crewList }: CrewMessengerProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [recipientId, setRecipientId] = useState<string>("");
  const [typedMessage, setTypedMessage] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [sending, setSending] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchMessages = async () => {
    try {
      const res = await fetch("/api/messages");
      if (res.ok) {
        const data = await res.json();
        setMessages(data);
      }
    } catch (err) {
      console.error("Error loading messages:", err);
    }
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(fetchMessages, 4000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Filter messages relevant to the logged-in user
  // (Either sent by this user or received by this user)
  const currentCrewId = session.crewId || "";
  const filteredMessages = messages.filter(
    (m) => m.senderId === currentCrewId || m.receiverId === currentCrewId
  );

  // Get recipient candidates (exclude self)
  const otherCrew = crewList.filter((c) => c.id !== currentCrewId);

  // Set recipient default
  useEffect(() => {
    if (otherCrew.length > 0 && !recipientId) {
      setRecipientId(otherCrew[0].id);
    }
  }, [otherCrew, recipientId]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMessage.trim() || !recipientId || !currentCrewId) return;

    setSending(true);
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: currentCrewId,
          senderName: session.name,
          receiverId: recipientId,
          content: typedMessage,
        }),
      });

      if (response.ok) {
        setTypedMessage("");
        await fetchMessages();
      }
    } catch (err) {
      console.error("Error posting message:", err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 shadow-xl flex flex-col h-[400px]">
      <div className="flex items-center justify-between border-b border-white/5 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-xs uppercase tracking-wider">Crew Communications</h3>
            <p className="text-[10px] text-slate-400">Secure message routing with active personnel</p>
          </div>
        </div>
        <span className="text-[9px] font-mono bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-full px-2.5 py-0.5 animate-pulse">
          Secure Line Live
        </span>
      </div>

      {/* Message History Scroller */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4">
            <MessageSquare className="w-8 h-8 text-white/10 mb-2" />
            <p className="text-[11px] text-slate-400 font-medium">No encrypted logs found on this terminal.</p>
            <p className="text-[9px] text-slate-500 mt-0.5">Select a crew member below to initiate routing.</p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isSelf = msg.senderId === currentCrewId;
            const textTime = new Date(msg.timestamp).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            });

            return (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[85%] ${
                  isSelf ? "ml-auto items-end" : "mr-auto items-start"
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-[9px] font-bold text-slate-400">
                    {isSelf ? "You" : msg.senderName}
                  </span>
                  <span className="text-[8px] font-mono text-slate-500 flex items-center gap-0.5">
                    <Clock className="w-2.5 h-2.5" />
                    {textTime}
                  </span>
                </div>
                <div
                  className={`p-3 rounded-2xl text-[11px] leading-relaxed shadow-md ${
                    isSelf
                      ? "bg-gradient-to-r from-cyan-600/70 to-blue-600/70 hover:from-cyan-600 hover:to-blue-600 text-white rounded-tr-none border border-cyan-500/15"
                      : "bg-white/5 hover:bg-white/8 text-slate-200 rounded-tl-none border border-white/5"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Form Composer */}
      <form onSubmit={handleSendMessage} className="border-t border-white/5 pt-3 mt-3 space-y-2">
        <div className="flex items-center gap-2">
          {/* Recipient Dropdown */}
          <div className="flex-1">
            <select
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              className="w-full bg-slate-900 border border-white/10 hover:border-white/20 rounded-xl py-1.5 px-2.5 text-[10px] font-bold text-slate-200 outline-none focus:border-cyan-400 transition-all cursor-pointer"
            >
              <option value="" disabled>Select Recipient...</option>
              {otherCrew.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.role})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex gap-2 relative">
          <input
            type="text"
            value={typedMessage}
            onChange={(e) => setTypedMessage(e.target.value)}
            placeholder="Type confidential operational message..."
            className="flex-1 bg-white/5 border border-white/10 focus:border-cyan-400/80 rounded-xl py-2 px-3 pl-3 pr-10 text-[11px] text-white placeholder-white/20 outline-none transition-all font-sans"
          />
          <button
            type="submit"
            disabled={sending || !typedMessage.trim() || !recipientId}
            className="absolute right-1 text-cyan-400 hover:text-cyan-300 disabled:text-slate-600 p-1.5 font-bold transition-all cursor-pointer self-center"
          >
            <Send className="w-4 h-4 shrink-0" />
          </button>
        </div>
      </form>
    </div>
  );
}
