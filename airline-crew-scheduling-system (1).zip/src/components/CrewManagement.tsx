import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  Plus,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Search,
  Filter,
  Check,
  X,
  AlertCircle,
  ArrowUpDown
} from "lucide-react";
import { Crew, Flight } from "../types";

interface CrewManagementProps {
  crewList: Crew[];
  flights: Flight[];
  onAddCrew: (crewData: Partial<Crew>) => Promise<any>;
  onUpdateCrew: (id: string, updates: Partial<Crew>) => Promise<any>;
  onDeleteCrew: (id: string) => Promise<any>;
  onAssignCrew: (flightId: string, crewId: string, assign: boolean) => Promise<any>;
  currentUserRole: string;
}

export default function CrewManagement({
  crewList,
  flights,
  onAddCrew,
  onUpdateCrew,
  onDeleteCrew,
  onAssignCrew,
  currentUserRole,
}: CrewManagementProps) {
  // Filters & State
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [sortField, setSortField] = useState<"flightHours" | "role" | "baseAirport" | "none">("none");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  // Form State
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    role: "Pilot",
    rank: "First Officer",
    baseAirport: "JFK",
    email: "",
    phone: "",
  });
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [contactingCrew, setContactingCrew] = useState<Crew | null>(null);
  const [assigningCrew, setAssigningCrew] = useState<Crew | null>(null);

  // Filtered and Sorted list
  const filteredCrew = useMemo(() => {
    const filtered = crewList.filter((crew) => {
      const matchesSearch =
        crew.name.toLowerCase().includes(search.toLowerCase()) ||
        crew.email.toLowerCase().includes(search.toLowerCase()) ||
        crew.baseAirport.toLowerCase().includes(search.toLowerCase());

      const matchesRole = roleFilter === "All" || crew.role === roleFilter;
      const matchesStatus = statusFilter === "All" || crew.status === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    });

    if (sortField === "none") return filtered;

    return [...filtered].sort((a, b) => {
      let comparison = 0;
      if (sortField === "flightHours") {
        comparison = a.flightHoursThisWeek - b.flightHoursThisWeek;
      } else if (sortField === "role") {
        comparison = a.role.localeCompare(b.role);
      } else if (sortField === "baseAirport") {
        comparison = a.baseAirport.localeCompare(b.baseAirport);
      }

      return sortOrder === "asc" ? comparison : -comparison;
    });
  }, [crewList, search, roleFilter, statusFilter, sortField, sortOrder]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formData.name.trim() || !formData.email.trim() || !formData.phone.trim()) {
      setFormError("All details are mandatory.");
      return;
    }

    setSubmitting(true);
    try {
      await onAddCrew({
        ...formData,
        role: formData.role as "Pilot" | "Cabin Crew",
      });
      setIsAdding(false);
      setFormData({
        name: "",
        role: "Pilot",
        rank: "First Officer",
        baseAirport: "JFK",
        email: "",
        phone: "",
      });
    } catch (err: any) {
      setFormError(err.message || "Could not save crew member.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to dismiss ${name} from the active operations registry?`)) {
      try {
        await onDeleteCrew(id);
      } catch (err: any) {
        alert(err.message || "Failed to remove crew member.");
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Add trigger */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Enterprise Crew Database</h2>
          <p className="text-xs text-slate-400 mt-1">
            Maintain employee profiles, base assignments, and duty hour safety compliance metrics.
          </p>
        </div>
        {currentUserRole === "Admin" && (
          <button
            onClick={() => setIsAdding(true)}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-[0.93] text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-lg shadow-cyan-500/10 active:scale-[0.98] transition-all cursor-pointer flex items-center gap-2 shrink-0 self-start sm:self-center"
          >
            <Plus className="w-4 h-4" />
            Enlist New Crew Member
          </button>
        )}
      </div>

      {/* Dynamic Search, Filter Controls */}
      <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row items-center gap-4">
        {/* Search */}
        <div className="relative w-full md:flex-1">
          <span className="absolute left-3 top-3 text-slate-400">
            <Search className="w-4.5 h-4.5" />
          </span>
          <input
            id="crew-search"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, base airport, or contact email..."
            className="w-full bg-white/5 border border-white/10 focus:border-cyan-400/80 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/20 rounded-xl py-2 pl-10 pr-4 text-xs tracking-wide text-white placeholder-white/20 focus:outline-none transition-all"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-300">Filters:</span>
          </div>

          <select
            id="role-filter"
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 focus:bg-slate-900"
          >
            <option value="All" className="bg-slate-950">All Roles</option>
            <option value="Pilot" className="bg-slate-950">Pilots Only</option>
            <option value="Cabin Crew" className="bg-slate-950">Cabin Crew Only</option>
          </select>

          <select
            id="status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 focus:bg-slate-900"
          >
            <option value="All" className="bg-slate-950">All Statuses</option>
            <option value="Active" className="bg-slate-950">Active</option>
            <option value="Resting" className="bg-slate-950">Resting</option>
            <option value="Standby" className="bg-slate-950">Standby</option>
            <option value="On Leave" className="bg-slate-950">On Leave</option>
          </select>
        </div>

        {/* Sorting Controls */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto md:border-l md:border-white/10 md:pl-4">
          <div className="flex items-center gap-1.5 shrink-0">
            <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs text-slate-300">Sort:</span>
          </div>

          <select
            id="sort-field"
            value={sortField}
            onChange={(e) => setSortField(e.target.value as any)}
            className="bg-white/5 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-cyan-400 focus:bg-slate-900"
          >
            <option value="none" className="bg-slate-950">None</option>
            <option value="flightHours" className="bg-slate-950">Flight Hours</option>
            <option value="role" className="bg-slate-950">Role</option>
            <option value="baseAirport" className="bg-slate-950">Base Airport</option>
          </select>

          {sortField !== "none" && (
            <button
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 text-xs text-cyan-400 font-bold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1"
              title={sortOrder === "asc" ? "Sorting Order: Ascending" : "Sorting Order: Descending"}
            >
              <span>{sortOrder === "asc" ? "▲ ASC" : "▼ DESC"}</span>
            </button>
          )}
        </div>
      </div>

      {/* Add Crew Modal Form Overlay */}
      {isAdding && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="backdrop-blur-3xl bg-slate-900/90 border border-white/10 rounded-3xl p-6 shadow-2xl max-w-md w-full relative">
            <button
              onClick={() => setIsAdding(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-white text-base mb-1">Enlist Crew Employee</h3>
            <p className="text-xs text-slate-400 mb-6">Specify the role and contact registration records.</p>

            {formError && (
              <div className="mb-4 p-3 backdrop-blur-md bg-red-500/10 border border-red-500/20 text-red-200 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Full Name</label>
                <input
                  id="form-name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., FO James Fletcher"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Functional Role</label>
                  <select
                    id="form-role"
                    value={formData.role}
                    onChange={(e) => {
                      const selectedRole = e.target.value;
                      setFormData({
                        ...formData,
                        role: selectedRole,
                        rank: selectedRole === "Pilot" ? "First Officer" : "Flight Attendant",
                      });
                    }}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-200 outline-none focus:border-cyan-400"
                  >
                    <option value="Pilot" className="bg-slate-950">Pilot</option>
                    <option value="Cabin Crew" className="bg-slate-950">Cabin Crew</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Designated Rank</label>
                  <select
                    id="form-rank"
                    value={formData.rank}
                    onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-200 outline-none focus:border-cyan-400"
                  >
                    {formData.role === "Pilot" ? (
                      <>
                        <option value="Captain" className="bg-slate-950">Captain</option>
                        <option value="First Officer" className="bg-slate-950">First Officer</option>
                        <option value="Second Officer" className="bg-slate-950">Second Officer</option>
                      </>
                    ) : (
                      <>
                        <option value="Lead Flight Attendant" className="bg-slate-950">Lead Flight Attendant</option>
                        <option value="Flight Attendant" className="bg-slate-950">Flight Attendant</option>
                        <option value="Junior Attendant" className="bg-slate-950">Junior Attendant</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Home Airport Base</label>
                  <select
                    id="form-base"
                    value={formData.baseAirport}
                    onChange={(e) => setFormData({ ...formData, baseAirport: e.target.value })}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-slate-200 outline-none focus:border-cyan-400"
                  >
                    <option value="JFK" className="bg-slate-950">JFK (New York)</option>
                    <option value="LAX" className="bg-slate-950">LAX (Los Angeles)</option>
                    <option value="SFO" className="bg-slate-950">SFO (San Francisco)</option>
                    <option value="ORD" className="bg-slate-950">ORD (Chicago)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Mobile Phone</label>
                  <input
                    id="form-phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1 (555) 123-4567"
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-300 mb-1">Corporate Email</label>
                <input
                  id="form-email"
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="e.g., james.f@skyline.com"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-3 text-xs text-white placeholder-white/20 outline-none focus:border-cyan-400 focus:bg-white/10 transition-all font-sans"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="flex-1 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl py-2.5 text-xs font-bold text-slate-300 transition-all cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 rounded-xl py-2.5 text-xs font-bold text-white transition-all cursor-pointer text-center flex items-center justify-center shadow-lg shadow-cyan-500/10"
                >
                  {submitting ? "Signing Record..." : "Confirm Registry"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Crew Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {filteredCrew.length === 0 ? (
            <motion.div
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              key="no-match"
              className="col-span-full backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl py-12 text-center text-slate-400"
            >
              <Users className="w-10 h-10 text-slate-500 mx-auto mb-2 animate-pulse" />
              <p className="text-xs">No crew members match compliance filters.</p>
            </motion.div>
          ) : (
            filteredCrew.map((crew) => {
              const utilization = Math.min((crew.flightHoursThisWeek / crew.maxWeeklyHours) * 100, 100);
              
              // Hours color-coding
              const getProgressColor = (hours: number) => {
                if (hours < 25) return "bg-gradient-to-r from-emerald-500 to-teal-400";
                if (hours < 35) return "bg-gradient-to-r from-amber-500 to-orange-400";
                return "bg-gradient-to-r from-red-500 to-rose-500";
              };

              const getProgressTextColor = (hours: number) => {
                if (hours < 25) return "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20";
                if (hours < 35) return "text-amber-400 bg-amber-500/10 border border-amber-500/20";
                return "text-red-400 bg-red-500/10 border border-red-500/20";
              };

              const getStatusBadge = (status: string) => {
                switch (status) {
                  case "Active":
                    return "text-emerald-400 bg-emerald-500/10 border-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.1)]";
                  case "Resting":
                    return "text-indigo-400 bg-indigo-500/10 border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.1)]";
                  case "Travelling":
                    return "text-blue-400 bg-blue-500/10 border-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.1)]";
                  case "Standby":
                    return "text-cyan-400 bg-cyan-500/10 border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.1)]";
                  case "On Leave":
                    return "text-red-400 bg-red-500/10 border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.1)]";
                  default:
                    return "text-slate-300 bg-white/5 border-white/10";
                }
              };

              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.2 }}
                  key={crew.id}
                  className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-3xl p-5 hover:border-white/20 hover:bg-white/8 transition-all font-sans relative flex flex-col justify-between"
                >
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-white shadow-lg ${crew.avatarColor}`}>
                        {crew.name.split(" ").pop()?.charAt(0) || "C"}
                      </div>
                      <div>
                        <h4 className="font-bold text-white text-sm">{crew.name}</h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] font-semibold uppercase bg-white/10 text-slate-300 px-1.5 py-0.5 rounded-md border border-white/5">
                            {crew.role}
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold">{crew.rank}</span>
                        </div>
                      </div>
                    </div>

                    <span className={`text-[10px] font-bold border rounded-full px-2.5 py-1 whitespace-nowrap ${getStatusBadge(crew.status)}`}>
                      {crew.status}
                    </span>
                  </div>

                  <div className="space-y-2 border-t border-b border-dashed border-white/5 py-3.5 my-3 text-[11px] text-slate-300">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400/80" />
                      <span>Airport Base: <strong className="text-white font-bold">{crew.baseAirport}</strong></span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400" />
                      <span className="truncate">{crew.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      <span>{crew.phone}</span>
                    </div>

                    {currentUserRole === "Admin" && (
                      <div className="mt-2.5 p-2 bg-blue-500/5 border border-blue-500/20 rounded-xl text-[10px] space-y-1 font-mono">
                        <div className="flex justify-between">
                          <span className="text-slate-450 uppercase text-[9px] font-bold">Username</span>
                          <strong className="text-cyan-400 font-bold">{crew.username || crew.name.toLowerCase().replace(/[^a-z0-9]/g, "")}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-450 uppercase text-[9px] font-bold">Password</span>
                          <strong className="text-amber-400 font-bold">{crew.password || "password123"}</strong>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Duty progress indicator */}
                  <div className="space-y-1.5 mb-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase text-slate-400">Weekly Duty Load</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase leading-none border ${getProgressTextColor(crew.flightHoursThisWeek)}`}>
                        {crew.flightHoursThisWeek}h / {crew.maxWeeklyHours}h Max Limit
                      </span>
                    </div>
                    <div className="relative w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${getProgressColor(crew.flightHoursThisWeek)}`}
                        style={{ width: `${utilization}%` }}
                      />
                    </div>
                  </div>
                </div>

                  <div className="flex flex-wrap items-center gap-2 pt-3 mt-auto border-t border-white/5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setAssigningCrew(crew);
                      }}
                      className="p-1 px-2 backdrop-blur-md bg-emerald-500/5 hover:bg-emerald-500/15 border border-emerald-500/20 hover:border-emerald-500/30 text-emerald-400 hover:text-emerald-300 font-bold rounded-xl transition-all text-[10px] flex items-center gap-1 cursor-pointer flex-1 justify-center whitespace-nowrap lg:flex-none lg:w-auto"
                    >
                      <ArrowUpDown className="w-3.5 h-3.5 shrink-0" />
                      Direct Assign
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setContactingCrew(crew);
                      }}
                      className="p-1 px-2 backdrop-blur-md bg-cyan-500/5 hover:bg-cyan-500/15 border border-cyan-500/20 hover:border-cyan-500/30 text-cyan-400 hover:text-cyan-300 font-bold rounded-xl transition-all text-[10px] flex items-center gap-1 cursor-pointer flex-1 justify-center whitespace-nowrap lg:flex-none lg:w-auto"
                    >
                      <Mail className="w-3.5 h-3.5 shrink-0" />
                      Contact
                    </button>

                    {currentUserRole === "Admin" ? (
                      <button
                        onClick={() => handleDelete(crew.id, crew.name)}
                        className="p-1.5 px-2 backdrop-blur-md bg-red-500/5 hover:bg-red-500/15 border border-red-500/20 hover:border-red-500/30 text-rose-400 hover:text-rose-300 font-bold rounded-xl transition-all text-[10px] flex items-center gap-1 cursor-pointer"
                        title="De-register"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      </button>
                    ) : <div />}
                  </div>
              </motion.div>
            );
          })
        )}
        </AnimatePresence>
      </div>

      {/* Quick Contact Modal */}
      {contactingCrew && (
        <div className="fixed inset-0 z-[60] overflow-y-auto bg-slate-950/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="backdrop-blur-3xl bg-slate-900/90 border border-white/10 rounded-3xl p-6 shadow-2xl max-w-md w-full relative">
            <button
              onClick={() => setContactingCrew(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-white text-base mb-1">Contact: {contactingCrew.name}</h3>
            <p className="text-xs text-slate-400 mb-5">Quick secure messaging and calling options.</p>

            {/* Aviation Rules Check */}
            <div className="mb-5 space-y-2">
              <h4 className="text-[10px] font-bold text-slate-300 uppercase tracking-wider mb-2 border-b border-white/10 pb-1">Aviation Rules & Conflicts</h4>
              {contactingCrew.status === "Resting" && (
                <div className="p-3 backdrop-blur-md bg-amber-500/10 border border-amber-500/20 text-amber-200 rounded-xl text-[10px] flex gap-2 flex-col">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span>Crew member is legally <strong>Resting</strong>. Please avoid non-emergency contact to respect mandatory minimum rest periods.</span>
                  </div>
                  {currentUserRole === "Admin" && (
                    <button
                      onClick={async () => {
                        await onUpdateCrew(contactingCrew.id, { status: "Active" });
                        setContactingCrew({ ...contactingCrew, status: "Active" });
                      }}
                      className="mt-2 w-full bg-amber-500/20 hover:bg-amber-500/30 text-amber-100 py-1.5 rounded-lg border border-amber-500/30 font-bold transition-colors cursor-pointer"
                    >
                      Emergency Override: Remove from Rest
                    </button>
                  )}
                </div>
              )}
              {contactingCrew.flightHoursThisWeek >= contactingCrew.maxWeeklyHours && (
                <div className="p-3 backdrop-blur-md bg-red-500/10 border border-red-500/20 text-red-200 rounded-xl text-[10px] flex gap-2 flex-col">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    <span>Crew has met or exceeded max weekly hours. Cannot be assigned to flights without standard FAA relief approvals.</span>
                  </div>
                  {currentUserRole === "Admin" && (
                    <button
                      onClick={async () => {
                        await onUpdateCrew(contactingCrew.id, { maxWeeklyHours: contactingCrew.maxWeeklyHours + 20 });
                        setContactingCrew({ ...contactingCrew, maxWeeklyHours: contactingCrew.maxWeeklyHours + 20 });
                      }}
                      className="mt-2 w-full bg-red-500/20 hover:bg-red-500/30 text-red-100 py-1.5 rounded-lg border border-red-500/30 font-bold transition-colors cursor-pointer"
                    >
                      Emergency Override: Extend Max Hours (+20h)
                    </button>
                  )}
                </div>
              )}
              {contactingCrew.status !== "Resting" && contactingCrew.flightHoursThisWeek < contactingCrew.maxWeeklyHours && (
                <div className="p-3 backdrop-blur-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 rounded-xl text-[10px] flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 shrink-0" />
                  <span>Crew member is available and compliant with operational directives.</span>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <a
                href={`mailto:${contactingCrew.email}?subject=Aviation%20Operations%20-%20Urgent%20Update`}
                onClick={() => setContactingCrew(null)}
                className="w-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-cyan-400/50 rounded-xl p-4 flex items-center gap-3 transition-all group cursor-pointer"
              >
                <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mail className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="text-sm font-bold text-white">Send Email Message</h4>
                  <p className="text-[10px] text-slate-400">Prefilled securely with ops template.</p>
                </div>
              </a>

              <a
                href={`tel:${contactingCrew.phone}`}
                onClick={() => setContactingCrew(null)}
                className="w-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-blue-400/50 rounded-xl p-4 flex items-center gap-3 transition-all group cursor-pointer"
              >
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Phone className="w-5 h-5 text-blue-400" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="text-sm font-bold text-white">Initiate Secure Call</h4>
                  <p className="text-[10px] text-slate-400">Directly via primary dispatch mobile.</p>
                </div>
              </a>
            </div>
            
            <button
              onClick={() => setContactingCrew(null)}
              className="mt-6 w-full text-center text-xs font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Direct Assign Modal */}
      {assigningCrew && (
         <div className="fixed inset-0 z-[60] overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
           <div className="backdrop-blur-3xl bg-slate-900/90 border border-white/10 rounded-3xl p-6 shadow-2xl max-w-md w-full relative">
             <button
               onClick={() => setAssigningCrew(null)}
               className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
             >
               <X className="w-5 h-5" />
             </button>
 
             <h3 className="font-bold text-white text-base mb-1">Direct Assign: {assigningCrew.name}</h3>
             <p className="text-xs text-slate-400 mb-5">Select an active or understaffed flight to assign.</p>

             <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                {flights
                  .filter(f => f.status === "On Time" || f.status === "Delayed") // Active flights
                  .filter(f => {
                    // Check if flight needs this role
                    if (assigningCrew.role === "Pilot") {
                      const currentPilots = crewList.filter(c => f.assignedCrewIds.includes(c.id) && c.role === "Pilot").length;
                      return currentPilots < f.requiredPilots;
                    } else {
                      const currentCabinCrew = crewList.filter(c => f.assignedCrewIds.includes(c.id) && c.role === "Cabin Crew").length;
                      return currentCabinCrew < f.requiredCabinCrew;
                    }
                  })
                  .map(flight => (
                  <div key={flight.id} className="bg-white/5 border border-white/10 p-3 rounded-xl flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-bold text-white uppercase">{flight.flightNumber}</div>
                      <div className="text-[10px] text-cyan-400 mt-0.5">{flight.origin} → {flight.destination}</div>
                    </div>
                    
                    <button
                      onClick={async () => {
                        try {
                           await onAssignCrew(flight.id, assigningCrew.id, true);
                           setAssigningCrew(null);
                        } catch(e: any) {
                           alert(e.message || "Failed to assign crew member");
                        }
                      }}
                      className="bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/30 text-cyan-400 text-[10px] font-bold py-1.5 px-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Assign {assigningCrew.role}
                    </button>
                  </div>
                ))}
                {flights.filter(f => f.status === "On Time" || f.status === "Delayed").filter(f => {
                    if (assigningCrew.role === "Pilot") {
                      const currentPilots = crewList.filter(c => f.assignedCrewIds.includes(c.id) && c.role === "Pilot").length;
                      return currentPilots < f.requiredPilots;
                    } else {
                      const currentCabinCrew = crewList.filter(c => f.assignedCrewIds.includes(c.id) && c.role === "Cabin Crew").length;
                      return currentCabinCrew < f.requiredCabinCrew;
                    }
                  }).length === 0 && (
                  <div className="text-center text-xs text-slate-500 p-4 border border-white/5 rounded-xl border-dashed">
                    No active understaffed flights found for {assigningCrew.role}s.
                  </div>
                )}
             </div>
           </div>
         </div>
      )}
    </div>
  );
}
