export interface Crew {
  id: string;
  name: string;
  role: 'Pilot' | 'Cabin Crew';
  rank: string; // e.g., Captain, First Officer, Lead Flight Attendant, Flight Attendant
  flightHoursThisWeek: number;
  maxWeeklyHours: number; // typically 40
  status: 'Active' | 'Resting' | 'On Leave' | 'Standby' | 'Travelling';
  baseAirport: string; // e.g. JFK, LAX, ORD, SFO
  email: string;
  phone: string;
  avatarColor: string; // Tailwind bg color class
  username?: string;
  password?: string;
}

export interface Flight {
  id: string;
  flightNumber: string;
  origin: string;
  destination: string;
  departureTime: string; // ISO String
  arrivalTime: string; // ISO String
  requiredPilots: number;
  requiredCabinCrew: number;
  status: 'On Time' | 'Delayed' | 'In-Flight' | 'Arrived' | 'Cancelled';
  aircraftType: string; // e.g. Boeing 737, Airbus A320, B787
  assignedCrewIds: string[];
}

export interface LeaveRequest {
  id: string;
  crewId: string;
  crewName: string;
  crewRole: string;
  type: 'Annual' | 'Medical' | 'Personal' | 'Other';
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  status: 'Pending' | 'Approved' | 'Rejected';
  reason: string;
  submittedAt: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'error' | 'success';
  timestamp: string; // ISO String
  read: boolean;
  flightId?: string; // Optional context linking
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: 'Admin' | 'Crew';
  crewId?: string; // If role is Crew, links to corresponding Crew record
}
