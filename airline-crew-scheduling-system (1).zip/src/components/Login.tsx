import React, { useState, useEffect } from "react";
import { Plane, Shield, User, Lock, AlertCircle, Sparkles, Mail, MapPin, CheckCircle } from "lucide-react";
import { User as UserType } from "../types";

interface LoginProps {
  onLoginSuccess: (user: UserType) => void;
}

const PRESET_CREW_PROFILES = [
  { name: "Capt. Sarah Rogers", role: "Captain & Pilot", username: "sarah", password: "password123", avatarColor: "bg-blue-600" },
  { name: "FO Aisha Bilal", role: "First Officer & Pilot", username: "aisha", password: "password123", avatarColor: "bg-emerald-600" },
  { name: "Purser Daniel Miller", role: "Purser Cabin Crew", username: "daniel", password: "password123", avatarColor: "bg-purple-600" },
  { name: "FA Chloe Bennett", role: "Flight Attendant", username: "chloe", password: "password123", avatarColor: "bg-pink-600" },
  { name: "FA Kenji Sato", role: "Flight Attendant", username: "kenji", password: "password123", avatarColor: "bg-cyan-600" },
  { name: "FA Liam O'Connor", role: "Flight Attendant", username: "liam", password: "password123", avatarColor: "bg-amber-600" }
];

export default function Login({ onLoginSuccess }: LoginProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  
  // Registration fields
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState("Cabin Crew");
  const [baseAirport, setBaseAirport] = useState("JFK");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedPresetName, setSelectedPresetName] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering) {
      if (!name || !email || !password || !phone) {
        setError("Please complete all fields.");
        return;
      }
    } else {
      if (!username || !password) {
        setError("Please complete all fields.");
        return;
      }
    }

    setLoading(true);
    setError(null);

    try {
      if (isRegistering) {
        // Create new crew
        const payloadUsername = name.toLowerCase().replace(/[^a-z0-9]/g, "");
        const crewRes = await fetch("/api/crew", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, phone, role, baseAirport, username: payloadUsername, password }),
        });
        
        if (!crewRes.ok) {
          throw new Error("Failed to register crew member.");
        }
        
        const newCrew = await crewRes.json();
        
        // Auto-login with the newly created profile
        onLoginSuccess({
          id: `user-${newCrew.id}`,
          username: newCrew.username || payloadUsername,
          name: newCrew.name,
          role: "Crew",
          crewId: newCrew.id,
        });

      } else {
        const response = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password }),
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.message || "Invalid authentication details.");
        }

        const user: UserType = await response.json();
        onLoginSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || "Sever communication error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handlePresetSelect = (uname: string, pass: string, profileName: string) => {
    setIsRegistering(false);
    setUsername(uname);
    setPassword(pass);
    setSelectedPresetName(profileName);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-white flex flex-col items-center justify-center relative overflow-hidden font-sans p-4">
      {/* Visual background atmospheric lights */}
      <div className="absolute top-[-25%] left-[-15%] w-[60%] h-[60%] rounded-full bg-blue-600/15 blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-25%] right-[-15%] w-[60%] h-[60%] rounded-full bg-indigo-600/15 blur-[140px] pointer-events-none" />
      <div className="absolute top-[30%] left-[30%] w-[40%] h-[40%] rounded-full bg-cyan-500/10 blur-[120px] pointer-events-none" />

      {/* Main card */}
      <div className="w-full max-w-lg backdrop-blur-2xl bg-white/5 border border-white/10 rounded-3xl p-8 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)] relative z-10 my-8">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 bg-gradient-to-tr from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center mb-4 text-white rotate-45 transform shadow-lg shadow-blue-500/20">
            <Plane className="w-8 h-8 -rotate-45 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white font-sans text-center">
            SKYFLOW <span className="font-light text-cyan-400">CREW</span>
          </h1>
          <p className="text-[10px] font-semibold tracking-[0.15em] text-slate-400 mt-1 uppercase text-center">
            {isRegistering ? "Crew Member Registration" : "Roster Control & Command Center"}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 backdrop-blur-md bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="text-xs text-red-200">{error}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegistering ? (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3 text-slate-400"><User className="w-4 h-4" /></span>
                  <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 pl-10 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Email</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3 text-slate-400"><Mail className="w-4 h-4" /></span>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@skyflow.com" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 pl-10 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Phone</label>
                  <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="555-0199" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 px-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                 <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Role</label>
                    <select value={role} onChange={(e) => setRole(e.target.value)} className="w-full bg-slate-800 border border-white/10 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 px-3 text-sm text-white transition-all outline-none">
                      <option value="Cabin Crew">Cabin Crew</option>
                      <option value="Pilot">Pilot</option>
                    </select>
                 </div>
                 <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Base Airport</label>
                    <div className="relative">
                       <span className="absolute left-3.5 top-3 text-slate-400"><MapPin className="w-4 h-4" /></span>
                       <input type="text" value={baseAirport} onChange={(e) => setBaseAirport(e.target.value)} placeholder="JFK" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 pl-10 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                    </div>
                 </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Set Password</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3 text-slate-400"><Lock className="w-4 h-4" /></span>
                  <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-2 pl-10 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                </div>
              </div>
            </>
          ) : (
            <>
              {selectedPresetName && (
                <div className="mb-4 p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl flex items-center justify-between text-xs text-cyan-300 animate-fade-in">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span>Autofilled credentials for <strong>{selectedPresetName}</strong>!</span>
                  </div>
                  <button type="button" onClick={() => { setUsername(""); setPassword(""); setSelectedPresetName(null); }} className="text-[10px] text-slate-400 hover:text-white font-bold underline">
                    Clear
                  </button>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Username or Email</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-slate-400"><User className="w-4.5 h-4.5" /></span>
                  <input id="username-input" type="text" value={username} onChange={(e) => { setUsername(e.target.value); setSelectedPresetName(null); }} placeholder="e.g., sarah" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-3 pl-11 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Password</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-slate-400"><Lock className="w-4.5 h-4.5" /></span>
                  <input id="password-input" type="password" value={password} onChange={(e) => { setPassword(e.target.value); setSelectedPresetName(null); }} placeholder="••••••••" className="w-full bg-white/5 border border-white/10 focus:border-cyan-400 focus:bg-white/10 focus:ring-1 focus:ring-cyan-500/30 rounded-xl py-3 pl-11 pr-4 text-sm text-white placeholder-white/20 transition-all outline-none" />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:opacity-90 active:scale-[0.98] text-white font-bold text-sm py-3 rounded-xl transition-all shadow-lg shadow-cyan-500/10 cursor-pointer flex items-center justify-center gap-2 mt-4"
          >
            {loading ? (
              <span className="inline-block border-2 border-white/30 border-t-white rounded-full w-4 h-4 animate-spin" />
            ) : (
              isRegistering ? "Register Profile & Login" : "Access Cockpit Console"
            )}
          </button>
        </form>

        <div className="mt-5 text-center">
          <button
            type="button"
            onClick={() => {
              setIsRegistering(!isRegistering);
              setError(null);
            }}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-bold transition-colors cursor-pointer"
          >
            {isRegistering ? "Already have a profile? Login" : "New member? Register Profile"}
          </button>
        </div>

        {!isRegistering && (
          <div className="mt-8 pt-6 border-t border-white/10">
            <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-4">Select Crew Member Profile</p>
            
            <div className="space-y-4">
              {/* Admin Portal selector */}
              <div className="flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-cyan-500/30 rounded-2xl transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 border border-cyan-500/20 shrink-0">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white leading-none">Administration Base Console</h4>
                    <span className="text-[9px] text-slate-400 mt-1 block">Full scheduling, co-pilot & rosters</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handlePresetSelect("admin", "admin", "Admin System")}
                  className="py-1.5 px-3 font-extrabold text-[10px] bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-500/20 text-cyan-400 rounded-xl transition-all cursor-pointer"
                >
                  Unify Admin
                </button>
              </div>

              {/* Grid of the 6 key crew members with unique accounts */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[220px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
                {PRESET_CREW_PROFILES.map((profile) => {
                  const isSelected = selectedPresetName === profile.name;
                  return (
                    <button
                      type="button"
                      key={profile.username}
                      onClick={() => handlePresetSelect(profile.username, profile.password, profile.name)}
                      className={`flex items-center text-left gap-2.5 p-2.5 bg-white/[0.03] hover:bg-white/[0.08] border rounded-2xl transition-all cursor-pointer group ${
                        isSelected 
                          ? "border-cyan-400 bg-cyan-500/5 shadow-[0_0_12px_rgba(34,211,238,0.1)]" 
                          : "border-white/5 hover:border-white/10"
                      }`}
                    >
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white shrink-0 shadow-sm ${profile.avatarColor}`}>
                        {profile.name.split(" ").pop()?.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h5 className="text-[11px] font-bold text-white truncate leading-none group-hover:text-cyan-400 transition-colors">
                          {profile.name}
                        </h5>
                        <p className="text-[8px] text-slate-400 font-mono mt-1 uppercase tracking-wide truncate">
                          {profile.role}
                        </p>
                      </div>
                      <span className="text-[8px] font-mono text-cyan-400 bg-cyan-400/10 border border-cyan-400/20 rounded-md px-1.5 py-0.5 shrink-0 opacity-80 group-hover:opacity-100 transition-opacity">
                        Fill
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 z-10 text-center space-y-1">
        <div className="text-[11px] font-medium text-slate-400 flex items-center justify-center gap-1.5 leading-none">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          FRONT END FRAMEWORKS & UI ENGINEERING PROJECT
        </div>
        <div className="text-[10px] text-slate-500 font-sans">
          Academic Term III, 2025-26 &bull; Created by Sampath & Jahnavi
        </div>
      </div>
    </div>
  );
}
